var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/setup/route.js")
R.c("server/chunks/[root-of-the-server]__0b6_qr5._.js")
R.c("server/chunks/[root-of-the-server]__1gwwrwu._.js")
R.c("server/chunks/_next-internal_server_app_api_setup_route_actions_0txsuev.js")
R.m(79384)
module.exports=R.m(79384).exports
