globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/LNj0QpKFzQKUjJuxru7xN/_buildManifest.js",
    "static/LNj0QpKFzQKUjJuxru7xN/_ssgManifest.js",
    "static/LNj0QpKFzQKUjJuxru7xN/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jq4o6yq14o4c.js",
    "static/chunks/0atut6a2uuyid.js",
    "static/chunks/3n7dm2ojtyzwn.js",
    "static/chunks/turbopack-405vyht2t-uf-.js"
  ]
};
